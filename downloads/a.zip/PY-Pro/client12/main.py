import socket,cpuinfo,json
import platform
import time,math,psutil
from subprocess import call,Popen,PIPE
from threading import Thread
if platform.system()=='Windows':
    import wmi
    computer=wmi.WMI()
    gpu_info=computer.Win32_VideoController()[0]
s=None
connection=False
version=0.5 #starversion
if platform.system()=='Linux':
    d=Popen(["lshw","-c","display"],stdout=PIPE).stdout.read()
    d=(str(d).split("\\n"))
    gpus=[]
    for g in d:
        if 'Produkt' in g or 'product' in g:
            gpus.append(g.lstrip()[9:])
    print(gpus)
def get_processor_name():
    return cpuinfo.get_cpu_info().get('brand')
def connect():
    global connection
    global s
    global version

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM,
        socket.IPPROTO_TCP)
        sockaddr =('192.168.0.59',5001)
        s.connect(sockaddr)
        print(s.getsockname()[0])
        if platform.system() == 'Windows':
            m='{"hostname": "'+ str(platform.node())  +  '","cpu":"' + get_processor_name()+'","ram":"' + str(math.ceil(psutil.virtual_memory()[0]/2.**30))+ '","gpu":"' +format(gpu_info.Name) +'"}'
        else:
            m = '{"hostname": "' + str(platform.node()) + '","cpu":"' + get_processor_name() + '","ram":"' + str(
                math.ceil(psutil.virtual_memory()[0] / 2. ** 30)) + '","gpu":"'+str(gpus)+'"}'
        print(m)
        mbytes=str.encode(m)
        s.send(mbytes)
        connection=True
        u = Thread(target=update)
        u.start()
        while(connection):
            recieved=s.recv(100)
            if(s.recv(100)== b''):
                print("No Connection,Server dead or CLient already connected")
                s.close()
                connection=False

            #starting to Update
            else:
                try:
                    jsonr=json.loads(recieved)
                    updateClient(jsonr)
                except json.decoder.JSONDecodeError:
                    continue
            time.sleep(10)
    except (ConnectionResetError,ConnectionRefusedError):
        print("No Connection,Server dead or CLient already connected")
        s.close()
        connection = False
def updateClient(jsono):
    file = open('updateinfo.txt', 'w')
    file.write('{"name": "'+jsono['name']+'", "version": "'+ str(jsono['version'])+'", "url": "' +jsono['url']+ '"}')

def update():
    global connection
    try:
        while connection:
            checkUpdate()
            print('UpdateRequest')
            s.send(str.encode('{"Update":"' + version +'"}'))
            time.sleep(10)
    except ConnectionResetError:
        connection=False
def checkUpdate():
    global version
    file=open('updateinfo.txt','r')
    info=json.loads(file.read())
    version=info['version']



while(True):
    if connection==False:
        print('Trying to connect')
        t=Thread(target=connect)
        t.start()

    time.sleep(60)